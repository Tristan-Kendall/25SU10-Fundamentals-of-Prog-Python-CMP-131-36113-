# Name
# CMP131
# 9/21/2021
# This program asks a user for their name and sends it to the hello function to print it out


print('Kate Austen')    # name and address.
print('123 Full Circle Drive')
print('Asheville, NC 28899')
