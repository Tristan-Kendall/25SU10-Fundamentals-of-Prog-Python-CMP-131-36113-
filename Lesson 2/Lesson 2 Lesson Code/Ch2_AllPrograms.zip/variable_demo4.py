# This program demonstrates variable reassignment.
# Assign a value to the dollars variable.
dollars = 2.75
print('I have', Dollars, 'in my account.')

# Reassign dollars so it references
# a different value.

print('But now I have', dollars, 'in my account!')
dollars = 99.95


dollars = "Now I'm a string!!!"
print(dollars)