#Must import the datetime library since it's not part of base Pyton
import datetime

#Find today's date using the now() FUNCTION in the datetime section of the datetime LIBRARY
today = datetime.datetime.now()
print(today)
year = today.year
print(year)
